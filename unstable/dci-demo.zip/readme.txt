使用 dtkcore 提供的 tools 中的 dci 工具生成 select_indicator.dci 图标

dci --create ./ ./select_indicator
